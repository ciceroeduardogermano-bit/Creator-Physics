# Creator Physics V1 — Manopola do Criador

Minecraft 1.21.1 / NeoForge 21.1.251

## O que funciona
- A Manopola do Criador aparece no inventário criativo na aba Creator Physics.
- A textura 16x16 está incluída.
- Clique com o botão direito em um bloco para marcar o Ponto A.
- Clique com o botão direito em outro bloco para marcar o Ponto B.
- O mod calcula os limites X/Y/Z da região e informa a quantidade de blocos.

## Próxima etapa
Esta versão ainda não move a estrutura. A física será adicionada depois que a seleção estiver funcionando.

## Compilar no Android
No Termux, dentro da pasta do projeto:

    chmod +x gradlew
    ./gradlew build

O JAR será gerado em `build/libs/`.
