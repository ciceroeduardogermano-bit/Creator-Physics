package com.creatorphysics;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class CreatorHandleItem extends Item {
    private static final Map<UUID, BlockPos> FIRST_POINTS = new ConcurrentHashMap<>();

    public CreatorHandleItem(Properties properties) {
        super(properties.stacksTo(1));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (context.getLevel().isClientSide()) {
            return InteractionResult.SUCCESS;
        }

        Player player = context.getPlayer();
        if (player == null) {
            return InteractionResult.PASS;
        }

        UUID id = player.getUUID();
        BlockPos clicked = context.getClickedPos().immutable();
        BlockPos first = FIRST_POINTS.get(id);

        if (first == null) {
            FIRST_POINTS.put(id, clicked);
            player.displayClientMessage(
                    Component.literal("Ponto A: " + format(clicked)), true);
            player.displayClientMessage(
                    Component.literal("Agora clique no segundo bloco."), false);
        } else {
            FIRST_POINTS.remove(id);

            int minX = Math.min(first.getX(), clicked.getX());
            int minY = Math.min(first.getY(), clicked.getY());
            int minZ = Math.min(first.getZ(), clicked.getZ());
            int maxX = Math.max(first.getX(), clicked.getX());
            int maxY = Math.max(first.getY(), clicked.getY());
            int maxZ = Math.max(first.getZ(), clicked.getZ());

            long blocks = (long) (maxX - minX + 1)
                    * (maxY - minY + 1)
                    * (maxZ - minZ + 1);

            player.displayClientMessage(
                    Component.literal("Ponto B: " + format(clicked)), true);
            player.displayClientMessage(
                    Component.literal("Área selecionada! " + blocks + " blocos."), false);
            player.displayClientMessage(
                    Component.literal("De [" + minX + ", " + minY + ", " + minZ + "] até ["
                            + maxX + ", " + maxY + ", " + maxZ + "]"), false);
        }

        return InteractionResult.SUCCESS;
    }

    private static String format(BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }
}
