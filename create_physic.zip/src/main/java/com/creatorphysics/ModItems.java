package com.creatorphysics;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;

public final class ModItems {
    private ModItems() {}

    public static final DeferredItem<Item> MANOPOLA_DO_CRIADOR =
            CreatorPhysics.ITEMS.register(
                    "manopola_do_criador",
                    () -> new CreatorHandleItem(new Item.Properties())
            );
}
